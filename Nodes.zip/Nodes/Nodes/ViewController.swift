//
//  ViewController.swift
//  Nodes
//
//  Created by Александр Скворцов on 23.12.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var nodeTextView: UITextView!

    var model: SomeNode?

    override func viewDidLoad() {
        super.viewDidLoad()
        nodeTextView.text = model?.text

        }

    @IBAction func saveButtonAction(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // определяем идентификатор segue
        switch segue.identifier {
        case "toFirstScreen":
            // обрабатываем переход
            prepareFirstScreen(segue)
        default:
            break
        }
    }

    // подготовка к переходу на первый экран
    private func prepareFirstScreen(_ segue: UIStoryboardSegue) {
        // безопасно извлекаем опциональное значение
        guard let destinationController = segue.destination as? MainViewController else {
            return }
        if let index = model?.index {
            destinationController.model[index] = .init(text: nodeTextView.text, index: index)
        } else {
            let newIndex = destinationController.model.count
            destinationController.model.append(.init(text: nodeTextView.text, index: newIndex))
        }
        StorageManager.shared.save(notes: destinationController.model)
        destinationController.tableView.reloadData()
    }

}
