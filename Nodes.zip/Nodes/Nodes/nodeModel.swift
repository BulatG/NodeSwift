//
//  nodeModel.swift
//  Nodes
//
//  Created by Александр Скворцов on 23.12.2022.
//

import Foundation

struct SomeNode: Codable {
    var text : String
    var index: Int?
}
