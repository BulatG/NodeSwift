//
//  CustomTableViewCell.swift
//  Nodes
//
//  Created by Александр Скворцов on 23.12.2022.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet var nodeTextLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func configureCell(textNode: String) {
        nodeTextLabel.text = textNode
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
