//
//  MainViewController.swift
//  Nodes
//
//  Created by Александр Скворцов on 23.12.2022.
//

import UIKit

class MainViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var model : [SomeNode] = StorageManager.shared.getNotes() ?? [.init(text: "Моя первая заметка", index: 0)]

    @IBOutlet weak var tableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! CustomTableViewCell

        cell.configureCell(textNode: model[indexPath.row].text)

        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = model[indexPath.row]
        performSegue(withIdentifier: "detailSegue", sender: model)
    }

    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .destructive, title: "Удалить") { [weak self] (action, view, completionHandler) in
            self?.removeNote(indexPath: indexPath)
            completionHandler(true)
        }
        return .init(actions: [action])

    }

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {

        if segue.identifier == "detailSegue", let model = sender as? SomeNode {
            let destinationConteroller = segue.destination as! ViewController
            destinationConteroller.model = model
        }
    }

    @IBAction func addNodeButtonAction(_ sender: Any) {

        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        _ = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        let model = SomeNode(text: "Введите текст")
        performSegue(withIdentifier: "detailSegue", sender: model)
    }

    @IBAction func unwindToFirstScreen(_ segue: UIStoryboardSegue) {}

    private func removeNote(indexPath: IndexPath) {
        self.model.remove(at: indexPath.row)
        self.tableView.deleteRows(at: [indexPath], with: .automatic)
    }
}
