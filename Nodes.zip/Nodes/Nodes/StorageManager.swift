//
//  StorageManager.swift
//  Nodes
//
//  Created by Александр Скворцов on 26.12.2022.
//

import Foundation

private let notesKey = "notes_storage_key"

class StorageManager {
    static let shared: StorageManager = StorageManager()

    func save(notes: [SomeNode]?) {
        if let data = try? JSONEncoder().encode(notes) {
            UserDefaults.standard.set(data, forKey: notesKey)
        }
    }

    func getNotes() -> [SomeNode]? {
        let data = UserDefaults.standard.object(forKey: notesKey)
        guard let data = data as? Data else { return nil }
        return try? JSONDecoder().decode([SomeNode].self, from: data)
    }
}
